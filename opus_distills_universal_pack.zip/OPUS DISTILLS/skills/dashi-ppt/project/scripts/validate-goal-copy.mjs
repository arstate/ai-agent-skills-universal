#!/usr/bin/env node
import { readFileSync } from 'node:fs';
import path from 'node:path';
import { isMediaArrayKey } from '../src/prop-contract-core.mjs';
import { isBespokeVariant, resolveContentMap } from '../src/variant-contract.mjs';
import { inspectLayout } from './skill-workflow-utils.mjs';

// 相对路径按调用方目录解析:npm run(含 --prefix)会把脚本 cwd 切到项目根,INIT_CWD 才是用户所在目录。
const CALLER_CWD = process.env.INIT_CWD || process.cwd();

const [, , specArg, htmlArg] = process.argv;

if (!specArg || !htmlArg) {
  console.error('Usage: node scripts/validate-goal-copy.mjs <goal-spec.json> <output/ppt/index.html>');
  process.exit(2);
}

const spec = JSON.parse(readFileSync(path.resolve(CALLER_CWD, specArg), 'utf8'));
const html = readFileSync(path.resolve(CALLER_CWD, htmlArg), 'utf8');
const layoutManifest = readLayoutManifest();
const specText = JSON.stringify(spec, null, 2);
const errors = [];
const COUNT_ARRAY_CANDIDATES = {
  barCount: ['bars'],
  calloutCount: ['callouts'],
  cardCount: ['cards'],
  chipCount: ['chips'],
  colCount: ['columns', 'cols'],
  featureCount: ['features', 'plans[].feats'],
  itemCount: ['items', 'stats', 'data'],
  stepCount: ['steps'],
  laneCount: ['lanes'],
  phaseCount: ['phases'],
  wordCount: ['words'],
  segCount: ['segments', 'segs'],
  roundCount: ['rounds'],
  milestoneCount: ['milestones'],
  statCount: ['stats'],
  pointCount: ['points'],
  planCount: ['plans'],
  rowCount: ['rows', 'features'],
  columnCount: ['columns', 'plans'],
  tileCount: ['tiles'],
  indexCount: ['items', 'index'],
  principleCount: ['principles', 'items'],
  supportingCount: ['supporting'],
  seriesCount: ['series'],
  segmentCount: ['segments'],
};
const NEUTRAL_PLACEHOLDERS = ['请输入文本', '请输入', '请输'];
const visibleText = extractSlideText(html, undefined, errors);
const COMMON_TERMS = new Set([
  '一个',
  '一份',
  '制作',
  '生成',
  '演示',
  '页面',
  '主题',
  '用户',
  '目标',
  '受众',
  '团队',
  '重要',
  '展示',
  '呈现',
]);

const groups = [
  {
    name: 'AI Capital / 投融资默认文案',
    allowWhen: /人工智能|资本|投资|融资|风投|估值|美元|\b(AI|VC|venture|OpenAI|xAI)\b/i,
    terms: [
      'AI CAPITAL',
      'AI Capital',
      'OpenAI',
      'xAI',
      'Anthropic',
      'Databricks',
      'Scale AI',
      '融资',
      '风投',
      '资本',
      '亿美元',
      '估值',
      '大模型',
      '投资判断',
    ],
  },
  {
    name: 'SoundWave / 声浪默认文案',
    allowWhen: /SoundWave|声浪|音乐|歌曲|歌手|乐队|创作者|发行|结算|版权|巡演|唱片/i,
    terms: [
      'SoundWave',
      '声浪',
      'Independent Music',
      '音乐人',
      '创作者',
      '发行',
      '结算',
      '版权',
      '巡演',
      '录音棚',
    ],
  },
];

for (const group of groups) {
  if (group.allowWhen.test(specText)) continue;
  const hits = group.terms.filter(term => visibleText.includes(term));
  if (hits.length) {
    errors.push(`${group.name}残留: ${hits.join(', ')}`);
  }
}

const unexpectedDefaultTerms = [
  'Key Metrics',
  '关键指标',
  '全景速览',
  'Roadmap',
  '布局路线',
  '阶段推进',
  'End of Report',
].filter(term => visibleText.includes(term) && !specText.includes(term));
if (unexpectedDefaultTerms.length) {
  errors.push(`未在 goal.json 中声明的模板默认文案残留: ${unexpectedDefaultTerms.join(', ')}`);
}

const neutralPlaceholders = findNeutralPlaceholders(visibleText);
if (neutralPlaceholders.length) {
  errors.push(`中性占位文案残留: ${neutralPlaceholders.join(', ')}`);
}

const requestedTerms = pickRequestedTerms(spec);
if (requestedTerms.length && !requestedTerms.some(term => visibleText.includes(term))) {
  errors.push(`输出正文没有命中用户目标关键词: ${requestedTerms.join(', ')}`);
}

validateCountControls(html, errors);
validateCoverCandidateUsage(html, errors);
validateVariantCopyCompleteness(html, errors);

if (errors.length) {
  console.error('Goal copy validation failed:');
  for (const error of errors) console.error(`- ${error}`);
  process.exit(1);
}

console.log('Goal copy validation passed.');

function pickRequestedTerms(spec) {
  const raw = [
    spec.title,
    spec.goal,
    spec.audience,
    spec.owner,
  ].filter(Boolean).join(' ');
  const terms = new Set();
  for (const match of raw.matchAll(/[\u4e00-\u9fa5]{2,}/g)) {
    const value = match[0];
    if (value.length <= 2) terms.add(value);
    else {
      terms.add(value.slice(0, 2));
      terms.add(value.slice(-2));
    }
  }
  for (const match of raw.matchAll(/[A-Za-z][A-Za-z0-9-]{2,}/g)) {
    terms.add(match[0]);
  }
  return [...terms].filter(term => !COMMON_TERMS.has(term)).slice(0, 12);
}

function extractSlideText(html, renderedText = extractRenderedSlideText(html), validationErrors = []) {
  return `${renderedText}\n${extractVisibleDeckPropsText(html, validationErrors)}`;
}

function extractRenderedSlideText(html) {
  const slides = [...html.matchAll(/<section\b[^>]*class="[^"]*\bslide\b[^"]*"[^>]*>[\s\S]*?<\/section>/g)]
    .map(match => match[0]);
  return decodeEntities(slides.map(slide => stripTags(slide)).join('\n'));
}

function extractVisibleDeckPropsText(markup, validationErrors = []) {
  const model = readJsonScript(markup, 'deck-view-model');
  if (!model?.slides?.length) return '';
  const sections = getSlideSections(markup);
  return JSON.stringify(model.slides.flatMap(logicalSlide => {
    return getSlideCandidates(logicalSlide).map(slide => {
      const section = findSlideSection(sections, logicalSlide, slide);
      if (isBespokeVariant(slide)) {
        return {
          kind: 'bespoke',
          composition: resolveCandidateComposition(logicalSlide, slide, validationErrors),
        };
      }
      const resolvedSlide = {
        ...slide,
        props: resolveCandidateProps(logicalSlide, slide, validationErrors),
      };
      return {
        layout: slide.layout,
        props: visiblePropsForSlide(
          resolvedSlide,
          readCandidateControls(logicalSlide, resolvedSlide, section),
          readArrayMeta(resolvedSlide),
        ),
      };
    });
  }));
}

function visiblePropsForSlide(slide, controls = [], arrayMeta = []) {
  const props = slide?.props || {};
  const bindings = getCountBindings(slide, controls, arrayMeta);
  const arrayCounts = new Map();
  for (const binding of bindings) {
    const count = numberOrNull(props[binding.key] ?? props[binding.publicKey]);
    if (count == null) continue;
    for (const arrayKey of binding.arrays || []) arrayCounts.set(arrayKey, count);
  }
  const fallbackCount = fallbackVisibleCount(props, bindings, controls);
  return filterVisibleValue(props, '', arrayCounts, fallbackCount);
}

function filterVisibleValue(value, pathName, arrayCounts, fallbackCount) {
  if (Array.isArray(value)) {
    const key = lastPathKey(pathName);
    const explicitCount = arrayCounts.get(pathName) ?? arrayCounts.get(key);
    const limit = explicitCount ?? (shouldSliceByFallback(key, value, fallbackCount) ? fallbackCount : null);
    const visible = limit == null ? value : value.slice(0, limit);
    const itemPath = pathName ? `${pathName}[]` : '[]';
    return visible.map(item => filterVisibleValue(item, itemPath, arrayCounts, fallbackCount));
  }
  if (!value || typeof value !== 'object') return value;
  return Object.fromEntries(Object.entries(value).map(([childKey, childValue]) => [
    childKey,
    filterVisibleValue(childValue, pathName ? `${pathName}.${childKey}` : childKey, arrayCounts, fallbackCount),
  ]));
}

function lastPathKey(pathName) {
  return String(pathName || '')
    .split('.')
    .at(-1)
    ?.replace(/\[\]$/, '') || '';
}

function fallbackVisibleCount(props, bindings, controls = []) {
  const countKeys = new Set();
  for (const binding of bindings || []) {
    if (binding.key) countKeys.add(binding.key);
    if (binding.publicKey) countKeys.add(binding.publicKey);
  }
  for (const control of controls || []) {
    if (!isNonMediaCountControl(control)) continue;
    if (control.key) countKeys.add(control.key);
    if (control.publicKey) countKeys.add(control.publicKey);
  }
  const counts = [...new Set([...countKeys]
    .map(key => numberOrNull(props[key]))
    .filter(value => value != null))];
  return counts.length === 1 ? counts[0] : null;
}

function isNonMediaCountControl(control) {
  const key = String(control?.key || control?.publicKey || '');
  const type = String(control?.type || '').toLowerCase();
  if (!/count$/i.test(key)) return false;
  if (type && !['number', 'range', 'slider'].includes(type)) return false;
  return !/(?:image|img|media|photo|video|avatar|logo|thumb|cover|poster|slot)/i.test(key);
}

function shouldSliceByFallback(key, value, fallbackCount) {
  if (fallbackCount == null || !Array.isArray(value) || value.length <= fallbackCount) return false;
  if (isMediaArrayKey(key)) return false;
  if (/^(items|cards|stats|data|captions|labels|callouts|features|tiles)$/i.test(String(key || ''))) return true;
  // The count→array binding table does not name every component's content array (e.g. nodes, tiers,
  // premises, shots). When a single page count resolves below the array length and the count-hidden
  // tail is neutral-placeholder filler padded for panel restore, slice it off so it is not scanned
  // as visible copy. Arrays whose tail is genuine copy stay intact, so real residue is still caught.
  return value.slice(fallbackCount).some(containsNeutralPlaceholder);
}

function containsNeutralPlaceholder(item) {
  if (item == null) return false;
  if (typeof item === 'string') return NEUTRAL_PLACEHOLDERS.some(placeholder => item.includes(placeholder));
  if (typeof item !== 'object') return false;
  const text = JSON.stringify(item);
  return NEUTRAL_PLACEHOLDERS.some(placeholder => text.includes(placeholder));
}


function numberOrNull(value) {
  const number = Number(value);
  return Number.isFinite(number) && number >= 0 ? Math.round(number) : null;
}

function findNeutralPlaceholders(text) {
  const hits = new Set();
  let value = String(text || '');
  for (const placeholder of NEUTRAL_PLACEHOLDERS) {
    if (!value.includes(placeholder)) continue;
    hits.add(placeholder);
    value = value.replaceAll(placeholder, '');
  }
  return [...hits];
}

function stripTags(markup) {
  return markup
    .replace(/<script\b[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style\b[\s\S]*?<\/style>/gi, ' ')
    .replace(/<svg\b[\s\S]*?<\/svg>/gi, ' ')
    .replace(/<[^>]+>/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function decodeEntities(value) {
  return value
    .replaceAll('&quot;', '"')
    .replaceAll('&amp;', '&')
    .replaceAll('&lt;', '<')
    .replaceAll('&gt;', '>')
    .replaceAll('&#x27;', "'")
    .replaceAll('&#39;', "'");
}

function validateCountControls(html, errors) {
  const model = readJsonScript(html, 'deck-view-model');
  if (!model?.slides?.length) return;
  const sections = getSlideSections(html);
  for (const logicalSlide of model.slides) {
    for (const slide of getSlideCandidates(logicalSlide)) {
      if (isBespokeVariant(slide)) continue;
      const section = findSlideSection(sections, logicalSlide, slide);
      if (!section) continue;
      const resolvedSlide = {
        ...slide,
        props: resolveCandidateProps(logicalSlide, slide, errors),
      };
      const controls = readCandidateControls(logicalSlide, resolvedSlide, section);
      for (const control of getCountBindings(resolvedSlide, controls, readArrayMeta(resolvedSlide))) {
        const key = control.key;
        const candidates = control.arrays || COUNT_ARRAY_CANDIDATES[key];
        if (!candidates?.length) continue;
        const props = resolvedSlide.props || {};
        const derived = deriveCount(props, key, candidates);
        if (!derived) continue;
        if (derived.error) errors.push(`${resolvedSlide.label || resolvedSlide.layout}: ${derived.error}`);
        else validateCountValue(resolvedSlide, control, derived, props, errors);
      }
    }
  }
}

function validateCoverCandidateUsage(html, errors) {
  const model = readJsonScript(html, 'deck-view-model');
  if (!model?.slides?.length) return;
  const coverSlides = model.slides.filter(slide => (
    getSlideCandidates(slide).some(candidate => /^theme\d+_page00[1-5]$/.test(candidate.layout))
  ));
  if (coverSlides.length > 1) {
    const layouts = coverSlides.flatMap(slide => (
      getSlideCandidates(slide)
        .map(candidate => candidate.layout)
        .filter(layout => /^theme\d+_page00[1-5]$/.test(layout))
    ));
    errors.push(`同一个 deck 只能使用 1 个封面候选页,当前使用了 ${coverSlides.length} 个: ${layouts.join(', ')}`);
  }
}

function validateVariantCopyCompleteness(html, errors) {
  const model = readJsonScript(html, 'deck-view-model');
  if (!model?.slides?.length) return;
  for (const logicalSlide of model.slides) {
    if (!Array.isArray(logicalSlide?.variants)) continue;
    for (const candidate of logicalSlide.variants) {
      if (isBespokeVariant(candidate)) continue;
      const fillPlan = inspectLayout(candidate.layout, { compact: true })?.fillPlan;
      if (!fillPlan) continue;
      const resolvedProps = resolveCandidateProps(logicalSlide, candidate, errors);
      const missing = [];
      for (const field of fillPlan.text || []) {
        if (!hasFilledPath(resolvedProps, field.key)) missing.push(field.key);
      }
      for (const field of fillPlan.arrays || []) {
        const arrays = readAuthoredArrays(resolvedProps, field.key);
        if (!arrays.length) {
          missing.push(field.key);
          continue;
        }
        const requestedCount = numberOrNull(resolvedProps?.[field.countKey]);
        const visibleCount = requestedCount ?? numberOrNull(field.visibleCount) ?? 0;
        arrays.forEach((items, arrayIndex) => {
          if (items.length < visibleCount) {
            missing.push(`${field.key}${arrays.length > 1 ? `[${arrayIndex}]` : ''}(${items.length}/${visibleCount})`);
            return;
          }
          if (!Object.keys(field.itemFields || {}).length) {
            for (let itemIndex = 0; itemIndex < visibleCount; itemIndex += 1) {
              if (!hasFilledValue(items[itemIndex])) missing.push(`${field.key}[${itemIndex}]`);
            }
          }
          for (let itemIndex = 0; itemIndex < visibleCount; itemIndex += 1) {
            for (const key of Object.keys(field.itemFields || {})) {
              if (!hasFilledPath(items[itemIndex], key)) {
                missing.push(`${field.key}[${itemIndex}].${key}`);
              }
            }
          }
        });
      }
      if (missing.length) {
        const label = candidate.label || candidate.id || candidate.layout;
        const preview = missing.slice(0, 8).join(', ');
        const suffix = missing.length > 8 ? ` 等 ${missing.length} 项` : '';
        errors.push(`${label}: 未覆写模板文案槽: ${preview}${suffix}`);
      }
    }
  }
}

function hasFilledPath(value, pathName) {
  const segments = String(pathName || '').split('.').filter(Boolean);
  let current = value;
  for (const segment of segments) {
    if (!current || typeof current !== 'object' || !Object.prototype.hasOwnProperty.call(current, segment)) {
      return false;
    }
    current = current[segment];
  }
  return hasFilledValue(current);
}

function hasFilledValue(value) {
  if (typeof value === 'string') return value.trim().length > 0;
  return value !== undefined && value !== null;
}

function readAuthoredArrays(value, pathName) {
  const segments = String(pathName || '').split('.').filter(Boolean);
  return collectArrayTargets(value, segments, 0);
}

function collectArrayTargets(value, segments, index) {
  if (!value || typeof value !== 'object' || index >= segments.length) return [];
  const raw = segments[index];
  const traversesArray = raw.endsWith('[]');
  const key = traversesArray ? raw.slice(0, -2) : raw;
  const next = value[key];
  if (index === segments.length - 1) return Array.isArray(next) ? [next] : [];
  if (traversesArray) {
    if (!Array.isArray(next)) return [];
    return next.flatMap(item => collectArrayTargets(item, segments, index + 1));
  }
  return collectArrayTargets(next, segments, index + 1);
}

function readLayoutManifest() {
  try {
    return JSON.parse(readFileSync('layout-manifest.json', 'utf8'));
  } catch {
    return null;
  }
}

function getCountBindings(slide, controls = [], arrayMeta = []) {
  const manifestBindings = layoutManifest?.layouts?.[slide.layout]?.countBindings;
  const metaBindings = arrayMetaCountBindings([
    ...(layoutManifest?.layouts?.[slide.layout]?.arrayMeta || []),
    ...(arrayMeta || []),
  ]);
  const explicitControlBindings = controlCountBindings(controls);
  const fallbackBindings = controls
    .filter(control => COUNT_ARRAY_CANDIDATES[control.key])
    .map(control => ({ ...control, arrays: COUNT_ARRAY_CANDIDATES[control.key] }));
  return mergeCountBindings(manifestBindings, metaBindings, explicitControlBindings, fallbackBindings);
}

function arrayMetaCountBindings(arrayMeta = []) {
  return (arrayMeta || [])
    .filter(meta => meta?.key && (meta.countKey || meta.publicCountKey))
    .map(meta => ({
      key: meta.countKey || meta.publicCountKey,
      publicKey: meta.publicCountKey || meta.countKey,
      arrays: [meta.key],
      min: meta.min,
      max: meta.max,
    }));
}

function controlCountBindings(controls = []) {
  const bindings = [];
  for (const control of controls || []) {
    const arrays = normalizeCountArrays(control.countArrays);
    if (arrays.length && control.key) {
      bindings.push({ ...control, arrays });
    }
    if (control.countKey && control.key && !isMediaArrayKey(control.key)) {
      bindings.push({
        key: control.countKey,
        publicKey: control.countKey,
        arrays: [control.key],
        min: control.min,
        max: control.max,
      });
    }
  }
  return bindings;
}

function normalizeCountArrays(value) {
  if (Array.isArray(value)) return value.filter(item => typeof item === 'string' && item);
  if (typeof value === 'string') return value.split(',').map(item => item.trim()).filter(Boolean);
  return [];
}

function mergeCountBindings(...groups) {
  const result = [];
  const seen = new Set();
  for (const binding of groups.flatMap(group => group || [])) {
    if (!binding?.key || seen.has(binding.key)) continue;
    seen.add(binding.key);
    result.push(binding);
  }
  return result;
}

function readArrayMeta(slide) {
  return Array.isArray(slide?.arrayMeta) ? slide.arrayMeta : [];
}

function getSlideCandidates(slide) {
  return Array.isArray(slide?.variants) && slide.variants.length ? slide.variants : [slide];
}

function resolveCandidateProps(logicalSlide, candidate, errors = []) {
  return resolveCandidateRenderData(logicalSlide, candidate, candidate?.props, 'props', errors);
}

function resolveCandidateComposition(logicalSlide, candidate, errors = []) {
  return resolveCandidateRenderData(logicalSlide, candidate, candidate?.composition, 'composition', errors);
}

function resolveCandidateRenderData(logicalSlide, candidate, base, field, errors) {
  if (!candidate?.contentMap || typeof candidate.contentMap !== 'object' || Array.isArray(candidate.contentMap)) {
    return base || {};
  }
  try {
    return resolveContentMap(logicalSlide?.content, candidate.contentMap, base || {});
  } catch (error) {
    const label = candidate.label || candidate.id || candidate.layout || 'variant';
    pushUniqueError(errors, `${label}: contentMap 无法从 sourceSlideId ${logicalSlide?.id || '<missing>'} 解析 ${field}: ${error.message}`);
    return base || {};
  }
}

function pushUniqueError(errors, error) {
  if (!errors.includes(error)) errors.push(error);
}

function readCandidateControls(logicalSlide, slide, section) {
  if (isBespokeVariant(slide)) return [];
  const manifestControls = layoutManifest?.layouts?.[slide.layout]?.controls || [];
  const sectionControls = readPropControls(section);
  if (!Array.isArray(logicalSlide?.variants) || !logicalSlide.variants.length) {
    return sectionControls.length ? sectionControls : manifestControls;
  }
  if (!isRenderedCandidate(logicalSlide, slide, section)) return manifestControls;
  return sectionControls.length ? sectionControls : manifestControls;
}

function isRenderedCandidate(logicalSlide, slide, section) {
  const renderedPhysicalId = getAttr(section, 'data-vm-slide-id');
  const renderedStateId = getAttr(section, 'data-vm-variant-state-id');
  if (renderedStateId) return slide.stateId === renderedStateId || renderedPhysicalId === slide.stateId;
  if (renderedPhysicalId && slide.stateId) return renderedPhysicalId === slide.stateId;
  if (logicalSlide.stateId) return slide.stateId === logicalSlide.stateId;
  if (logicalSlide.selectedVariant) {
    return slide.id === logicalSlide.selectedVariant || slide.stateId === logicalSlide.selectedVariant;
  }
  return slide.layout === logicalSlide.layout;
}

function deriveCount(props, key, candidates) {
  const counts = [];
  if (key === 'phaseCount' && Array.isArray(props.lanes)) {
    props.lanes.forEach((lane, index) => {
      if (Array.isArray(lane.items)) counts.push({ source: `lanes[${index}].items`, count: lane.items.length });
    });
  }
  for (const arrayKey of candidates) {
    counts.push(...collectArrayCounts(props, arrayKey));
  }
  if (!counts.length) return null;
  if (candidates.some(isNestedArrayPath)) return collapseNestedCounts(counts);
  return collapseCounts(counts);
}

function collectArrayCounts(value, pathName, sourcePrefix = '') {
  if (!value || typeof value !== 'object') return [];
  const [segment, ...restParts] = String(pathName || '').split('.');
  const rest = restParts.join('.');
  const arraySegment = segment.endsWith('[]');
  const key = arraySegment ? segment.slice(0, -2) : segment;
  const next = value[key];
  const source = sourcePrefix ? `${sourcePrefix}.${key}` : key;

  if (arraySegment) {
    if (!Array.isArray(next)) return [];
    if (!rest) return [{ source, count: next.length }];
    return next.flatMap((item, index) => collectArrayCounts(item, rest, `${source}[${index}]`));
  }

  if (!rest) {
    return Array.isArray(next) ? [{ source, count: next.length }] : [];
  }
  return collectArrayCounts(next, rest, source);
}

function isNestedArrayPath(pathName) {
  return String(pathName || '').includes('[].');
}

function collapseCounts(counts) {
  const unique = [...new Set(counts.map(item => item.count))];
  if (unique.length > 1) {
    return { error: `${counts.map(item => `${item.source}=${item.count}`).join(', ')} 数量不一致` };
  }
  return {
    count: unique[0],
    source: counts.map(item => item.source).join('/'),
  };
}

function collapseNestedCounts(counts) {
  return {
    count: Math.min(...counts.map(item => item.count)),
    source: counts.map(item => `${item.source}=${item.count}`).join('/'),
  };
}

function validateCountValue(slide, control, derived, props, errors) {
  const current = Number(props[control.key]);
  if (!Number.isFinite(current)) {
    errors.push(`${slide.label || slide.layout}: ${control.key} 缺失或不是有效数字,但 ${derived.source} 有 ${derived.count} 条`);
    return;
  }
  if (current > derived.count) {
    errors.push(`${slide.label || slide.layout}: ${control.key}=${current},但 ${derived.source} 只有 ${derived.count} 条`);
  }
  const min = Number(control.min);
  const max = Number(control.max);
  if (Number.isFinite(min) && current < min) {
    errors.push(`${slide.label || slide.layout}: ${control.key}=${current} 小于最小值 ${min}`);
  }
  if (Number.isFinite(max) && current > max) {
    errors.push(`${slide.label || slide.layout}: ${control.key}=${current} 大于最大值 ${max}`);
  }
}

function readJsonScript(html, id) {
  const match = html.match(new RegExp(`<script[^>]*id="${id}"[^>]*>([\\s\\S]*?)<\\/script>`));
  if (!match) return null;
  try {
    return JSON.parse(match[1]);
  } catch {
    return null;
  }
}

function getSlideSections(html) {
  const sections = [];
  for (const match of html.matchAll(/<section\b[\s\S]*?<\/section>/g)) {
    const markup = match[0];
    const id = getAttr(markup, 'data-vm-slide-id');
    if (!id) continue;
    sections.push({
      id,
      sourceSlideId: getAttr(markup, 'data-vm-source-slide-id'),
      stateId: getAttr(markup, 'data-vm-variant-state-id'),
      variantId: getAttr(markup, 'data-vm-variant-id'),
      markup,
    });
  }
  return sections;
}

function findSlideSection(sections, logicalSlide, candidate) {
  const sourceSlideId = String(
    candidate?.sourceSlideId
      || logicalSlide?.sourceSlideId
      || logicalSlide?.id
      || '',
  );
  const variantId = String(candidate?.variantId || candidate?.id || '');
  const stateId = String(
    candidate?.stateId
      || (sourceSlideId && variantId ? `${sourceSlideId}::${variantId}` : ''),
  );
  const exact = sections.find(section => (
    (stateId && (section.id === stateId || section.stateId === stateId))
    || (candidate?.id && section.id === candidate.id && section.sourceSlideId === sourceSlideId)
  ));
  if (exact) return exact.markup;

  const grouped = sections.find(section => (
    section.sourceSlideId === sourceSlideId
    && (!section.variantId || !variantId || section.variantId === variantId)
  ));
  if (grouped) return grouped.markup;

  const legacy = sections.find(section => section.id === logicalSlide?.id);
  return legacy?.markup || '';
}

function readPropControls(section) {
  const raw = getAttr(section, 'data-prop-controls');
  if (!raw) return [];
  try {
    return JSON.parse(decodeEntities(raw));
  } catch {
    return [];
  }
}

function getAttr(markup, name) {
  const match = markup.match(new RegExp(`${name}="([^"]*)"`));
  return match ? match[1] : '';
}
