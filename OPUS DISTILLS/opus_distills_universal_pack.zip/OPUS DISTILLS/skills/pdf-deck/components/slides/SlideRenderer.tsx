'use client';

import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Slide, ThemeConfig, TransitionConfig, ChromeStyle } from '../../types/slide';
import { SvgIcon, TelemetryCrosshair, StatusPill } from './SvgIcon';
import { SlideImageFrame } from './SlideImageFrame';
import { DEFAULT_SLIDE_IMAGE, DEFAULT_TEAM_MEMBERS, DEFAULT_PROCESS_STEPS } from '../../presets/curatedPhotos';
import { resolveLayoutMeta } from '../../presets/layoutCatalog';
import { isColorLight } from '../../presets/themes';
import {
  renderAiKlyroHero,
  renderAiKlyroSplitStats,
  renderAiKlyroTicketPrinciples,
  renderAiChuckleRetroHero,
  renderAiBorcelleDonutData,
  renderAiBorcelleVennDiagram,
  renderAiFintechRibbonWave,
} from './AiGenCreativeLayouts';

interface SlideRendererProps {
  slide: Slide;
  theme: ThemeConfig;
  transition: TransitionConfig;
  index: number;
  totalSlides: number;
  isThumbnail?: boolean;
  isEditMode?: boolean;
  selectedId?: string | null;
  chromeStyle?: ChromeStyle;
  brandLabel?: string;
  onSelectElement?: (id: string | null) => void;
  onUpdateSlide?: (updater: (prev: Slide) => Slide) => void;
  onOpenImageEditor?: (imageKey: string) => void;
}

interface EditableTextProps {
  value: string;
  onSave?: (newVal: string) => void;
  className?: string;
  style?: React.CSSProperties;
  isEditMode?: boolean;
  isSelected?: boolean;
  onSelect?: () => void;
  as?: 'h1' | 'h2' | 'h3' | 'p' | 'span' | 'div';
  placeholder?: string;
  layoutId?: string;
}

/**
 * High-performance on-canvas PowerPoint-like editable text block.
 * When isEditMode is true: enables direct inline contentEditable editing with visual selection handles.
 * When isEditMode is false: renders pristine presentation typography without overhead.
 */
const EditableText: React.FC<EditableTextProps> = ({
  value,
  onSave,
  className = '',
  style,
  isEditMode = false,
  isSelected = false,
  onSelect,
  as = 'div',
  placeholder = 'Click to edit...',
  layoutId,
}) => {
  const handleBlur = (e: React.FocusEvent<HTMLElement>) => {
    if (!isEditMode || !onSave) return;
    const text = e.currentTarget.innerText || '';
    if (text !== value) {
      onSave(text.trim());
    }
  };

  const handleClick = (e: React.MouseEvent) => {
    if (isEditMode) {
      e.stopPropagation();
      onSelect?.();
    }
  };

  const editClasses = isEditMode
    ? `cursor-text transition-all rounded px-1 -mx-1 relative ${
        isSelected
          ? 'outline outline-2 outline-emerald-400 bg-emerald-500/10 ring-1 ring-emerald-400/50'
          : 'hover:outline hover:outline-1 hover:outline-dashed hover:outline-[#52525b] focus:outline focus:outline-2 focus:outline-emerald-400 focus:bg-white/5'
      }`
    : '';

  const Tag = as as any;

  const selectionHandles = isEditMode && isSelected ? (
    <>
      <span className="absolute -top-1 -left-1 h-2 w-2 bg-emerald-400 border border-black pointer-events-none z-20" />
      <span className="absolute -top-1 -right-1 h-2 w-2 bg-emerald-400 border border-black pointer-events-none z-20" />
      <span className="absolute -bottom-1 -left-1 h-2 w-2 bg-emerald-400 border border-black pointer-events-none z-20" />
      <span className="absolute -bottom-1 -right-1 h-2 w-2 bg-emerald-400 border border-black pointer-events-none z-20" />
    </>
  ) : null;

  if (layoutId) {
    return (
      <motion.div
        layoutId={layoutId}
        contentEditable={isEditMode}
        suppressContentEditableWarning
        onBlur={handleBlur}
        onClick={handleClick}
        className={`${className} ${editClasses}`}
        style={style}
        data-placeholder={placeholder}
      >
        {value}
        {selectionHandles}
      </motion.div>
    );
  }

  return (
    <Tag
      contentEditable={isEditMode}
      suppressContentEditableWarning
      onBlur={handleBlur}
      onClick={handleClick}
      className={`${className} ${editClasses}`}
      style={style}
      data-placeholder={placeholder}
    >
      {value}
      {selectionHandles}
    </Tag>
  );
};

export const SlideRenderer: React.FC<SlideRendererProps> = ({
  slide,
  theme,
  transition,
  index,
  totalSlides,
  isThumbnail = false,
  isEditMode = false,
  selectedId = null,
  chromeStyle,
  brandLabel,
  onSelectElement,
  onUpdateSlide,
  onOpenImageEditor,
}) => {
  const effectiveChrome: ChromeStyle = chromeStyle || slide.chromeStyle || 'minimal';
  const effectiveBrand: string = brandLabel || 'PRESENTATION';
  // Determine motion transition variants based on configured transition type
  const getVariants = () => {
    if (isThumbnail) {
      return {
        initial: { opacity: 1 },
        animate: { opacity: 1 },
        exit: { opacity: 1 },
      };
    }

    switch (transition.type) {
      case 'morph':
        return {
          initial: { opacity: 0, y: 12 },
          animate: { opacity: 1, y: 0 },
          exit: { opacity: 0, y: -12 },
        };
      case 'crossfade':
        return {
          initial: { opacity: 0 },
          animate: { opacity: 1 },
          exit: { opacity: 0 },
        };
      case 'slide-x':
        return {
          initial: { opacity: 0, x: 80 },
          animate: { opacity: 1, x: 0 },
          exit: { opacity: 0, x: -80 },
        };
      case 'slide-y':
        return {
          initial: { opacity: 0, y: 80 },
          animate: { opacity: 1, y: 0 },
          exit: { opacity: 0, y: -80 },
        };
      case 'scale-zoom':
        return {
          initial: { opacity: 0, scale: 0.94 },
          animate: { opacity: 1, scale: 1 },
          exit: { opacity: 0, scale: 1.04 },
        };
      case 'clip-reveal':
        return {
          initial: { opacity: 0, clipPath: 'inset(10% 10% 10% 10%)' },
          animate: { opacity: 1, clipPath: 'inset(0% 0% 0% 0%)' },
          exit: { opacity: 0, clipPath: 'inset(5% 5% 5% 5%)' },
        };
      case 'flip-3d':
        return {
          initial: { opacity: 0, rotateY: 30, transformPerspective: 1000 },
          animate: { opacity: 1, rotateY: 0, transformPerspective: 1000 },
          exit: { opacity: 0, rotateY: -30, transformPerspective: 1000 },
        };
      case 'stagger-blur':
        return {
          initial: { opacity: 0, filter: 'blur(12px)', scale: 0.98 },
          animate: { opacity: 1, filter: 'blur(0px)', scale: 1 },
          exit: { opacity: 0, filter: 'blur(8px)', scale: 1.02 },
        };
      default:
        return {
          initial: { opacity: 0 },
          animate: { opacity: 1 },
          exit: { opacity: 0 },
        };
    }
  };

  const variants = getVariants();
  const transitionConfig = {
    duration: isThumbnail ? 0 : isEditMode ? 0.1 : Math.min(transition.duration || 0.3, 0.35),
    ease: [0.16, 1, 0.3, 1] as [number, number, number, number],
  };

  const isMorph = transition.type === 'morph' && !isEditMode && !isThumbnail;

  const isHtmlSlide = slide.layout === 'html' || slide.layout === 'bespoke' || Boolean(slide.rawHtml || slide.elements?.rawHtml);

  // If the slide is an arbitrary / bespoke HTML slide, render it full-bleed (1920x1080)
  // without forcing engine chrome, borders, paddings, watermarks, or studio theme colors.
  if (isHtmlSlide) {
    const raw = slide.rawHtml || slide.elements?.rawHtml || '';
    const isFullDoc = raw.includes('<html') || raw.includes('<!DOCTYPE') || raw.includes('<body') || raw.includes('<head');

    return (
      <div
        id={`slide-canvas-${slide.id}`}
        onClick={() => {
          if (isEditMode) onSelectElement?.(null);
        }}
        className={`relative select-none overflow-hidden ${isEditMode ? 'ring-1 ring-emerald-500/30' : ''}`}
        style={{
          width: 1920,
          height: 1080,
          backgroundColor: 'transparent',
        }}
      >
        <AnimatePresence mode="wait" initial={false}>
          <motion.div
            key={slide.id}
            initial={variants.initial}
            animate={variants.animate}
            exit={variants.exit}
            transition={transitionConfig}
            className="relative w-[1920px] h-[1080px] overflow-hidden"
            style={{ width: 1920, height: 1080 }}
          >
            {isFullDoc ? (
              <iframe
                srcDoc={raw}
                title={`html-slide-${slide.id}`}
                className="w-[1920px] h-[1080px] border-0 overflow-hidden block"
                style={{ width: '1920px', height: '1080px', border: 0 }}
                sandbox="allow-scripts allow-same-origin allow-popups"
              />
            ) : (
              <div
                className="w-[1920px] h-[1080px] relative overflow-hidden"
                style={{ width: 1920, height: 1080 }}
                dangerouslySetInnerHTML={{
                  __html: raw || '<div style="display:flex;align-items:center;justify-content:center;height:100%;color:#888;font-family:sans-serif;font-size:24px;">Empty HTML Slide</div>',
                }}
              />
            )}
          </motion.div>
        </AnimatePresence>
      </div>
    );
  }

  const slideBg = slide.elements.bg || slide.elements.bgColor || theme.bg;
  const isSlideDark = !isColorLight(slideBg);

  // Dynamic subtle border & accents: zero clashing neon strokes, perfectly harmonious with slide bg
  const slideBorder =
    theme.id === 'ai-gen' || slide.elements.bg || slide.elements.bgColor
      ? isSlideDark
        ? 'rgba(255, 255, 255, 0.08)'
        : 'rgba(0, 0, 0, 0.06)'
      : theme.border;

  const slideAccent =
    theme.id === 'ai-gen' || slide.elements.bg || slide.elements.bgColor
      ? isSlideDark
        ? 'rgba(255, 255, 255, 0.4)'
        : '#0F172A'
      : theme.accent;

  return (
    <div
      id={`slide-canvas-${slide.id}`}
      onClick={() => {
        if (isEditMode) onSelectElement?.(null);
      }}
      className={`relative select-none overflow-hidden ${isEditMode ? 'ring-1 ring-emerald-500/30' : ''}`}
      style={{
        width: 1920,
        height: 1080,
        backgroundColor: slideBg,
        color:
          slide.elements.textColor ||
          (isSlideDark ? '#ffffff' : '#111827'),
        fontFamily: theme.fontBody,
      }}
    >
      {/* Background subtle micro-grid watermark for engineering rigor */}
      <div
        className="pointer-events-none absolute inset-0 opacity-[0.035]"
        style={{
          backgroundImage: `linear-gradient(to right, ${slideBorder} 1px, transparent 1px), linear-gradient(to bottom, ${slideBorder} 1px, transparent 1px)`,
          backgroundSize: '80px 80px',
        }}
      />

      {/* Frame perimeter hairline border removed to eliminate ugly outer stroke */}

      <AnimatePresence mode="wait" initial={false}>
        <motion.div
          key={slide.id}
          initial={variants.initial}
          animate={variants.animate}
          exit={variants.exit}
          transition={transitionConfig}
          className="relative flex h-full w-full flex-col justify-between px-20 py-10"
        >
          {/* TOP METADATA BAR / FOLIO (varied yet consistent within deck) */}
          {effectiveChrome !== 'clean-bleed' && (
            <div
              className={`flex items-center justify-between pb-4 ${
                effectiveChrome === 'editorial' || effectiveChrome === 'classic-rule'
                  ? 'border-b'
                  : ''
              }`}
              style={{
                borderColor: effectiveChrome === 'classic-rule' ? slideAccent : slideBorder,
              }}
            >
              {effectiveChrome === 'badge-capsule' ? (
                <div
                  className="inline-flex items-center gap-2.5 rounded-full px-4 py-1.5 border"
                  style={{ backgroundColor: theme.surface, borderColor: slideBorder }}
                >
                  <span className="h-2 w-2 rounded-full" style={{ backgroundColor: slideAccent }} />
                  <EditableText
                    value={slide.kicker || 'EXECUTIVE BRIEFING'}
                    isEditMode={isEditMode}
                    isSelected={selectedId === 'kicker'}
                    onSelect={() => onSelectElement?.('kicker')}
                    onSave={(val) => onUpdateSlide?.((prev) => ({ ...prev, kicker: val }))}
                    className="text-xs font-mono font-bold tracking-wider uppercase"
                    style={{ color: theme.textPrimary }}
                    as="span"
                  />
                </div>
              ) : effectiveChrome === 'creative-studio' ? (
                <div className="flex items-center gap-3">
                  <span
                    className="rounded-full px-3.5 py-1 text-xs font-mono font-black tracking-widest uppercase border shadow-sm"
                    style={{
                      backgroundColor: slideAccent,
                      borderColor: slideAccent,
                      color: '#000000',
                    }}
                  >
                    {effectiveBrand}
                  </span>
                  <EditableText
                    value={slide.kicker || 'CREATIVE BRIEF'}
                    isEditMode={isEditMode}
                    isSelected={selectedId === 'kicker'}
                    onSelect={() => onSelectElement?.('kicker')}
                    onSave={(val) => onUpdateSlide?.((prev) => ({ ...prev, kicker: val }))}
                    className="text-xs font-mono font-bold tracking-widest uppercase"
                    style={{ color: theme.textMuted }}
                    as="span"
                  />
                </div>
              ) : effectiveChrome === 'editorial' ? (
                <motion.div
                  layoutId={transition.type === 'morph' ? 'slide-kicker' : undefined}
                  className="flex items-center gap-3.5"
                >
                  <span
                    className="text-xs font-mono font-bold tracking-[0.25em] uppercase px-2.5 py-0.5 border"
                    style={{
                      backgroundColor: theme.surfaceRaised,
                      borderColor: slideBorder,
                      color: theme.textSecondary,
                    }}
                  >
                    {effectiveBrand}
                  </span>
                  <span className="font-mono text-xs" style={{ color: slideBorder }}>|</span>
                  <EditableText
                    value={slide.kicker || 'EXECUTIVE REPORT'}
                    isEditMode={isEditMode}
                    isSelected={selectedId === 'kicker'}
                    onSelect={() => onSelectElement?.('kicker')}
                    onSave={(val) => onUpdateSlide?.((prev) => ({ ...prev, kicker: val }))}
                    className="text-sm font-mono font-bold tracking-[0.2em] uppercase"
                    style={{ color: theme.textMuted }}
                    as="span"
                  />
                </motion.div>
              ) : effectiveChrome === 'classic-rule' ? (
                <div className="flex items-center gap-3">
                  <span className="h-3 w-3" style={{ backgroundColor: slideAccent }} />
                  <EditableText
                    value={slide.kicker || 'STRATEGIC REPORT'}
                    isEditMode={isEditMode}
                    isSelected={selectedId === 'kicker'}
                    onSelect={() => onSelectElement?.('kicker')}
                    onSave={(val) => onUpdateSlide?.((prev) => ({ ...prev, kicker: val }))}
                    className="text-sm font-mono font-bold tracking-[0.25em] uppercase"
                    style={{ color: theme.textPrimary }}
                    as="span"
                  />
                </div>
              ) : (
                /* minimal: clean kicker with subtle accent square */
                <motion.div
                  layoutId={transition.type === 'morph' ? 'slide-kicker' : undefined}
                  className="flex items-center gap-3"
                >
                  <span
                    className="inline-block h-2 w-2 rounded-none opacity-60"
                    style={{ backgroundColor: slideAccent }}
                  />
                  <EditableText
                    value={slide.kicker || 'EXECUTIVE BRIEFING'}
                    isEditMode={isEditMode}
                    isSelected={selectedId === 'kicker'}
                    onSelect={() => onSelectElement?.('kicker')}
                    onSave={(val) => onUpdateSlide?.((prev) => ({ ...prev, kicker: val }))}
                    className="text-base font-mono font-bold tracking-[0.2em] uppercase"
                    style={{ color: isSlideDark ? 'rgba(255, 255, 255, 0.7)' : 'rgba(0, 0, 0, 0.7)' }}
                    as="span"
                  />
                </motion.div>
              )}
            </div>
          )}

          {/* MAIN BODY AREA DEPENDING ON LAYOUT */}
          <div className="my-auto flex flex-1 flex-col justify-center py-2 min-h-0">
            {renderLayoutContent(slide, theme, isMorph, isEditMode, selectedId, onSelectElement, onUpdateSlide, onOpenImageEditor)}
          </div>

          {/* BOTTOM FOOTER / MANDATORY BOTTOM-RIGHT PAGE COUNTER */}
          <div
            className={`flex items-center justify-between pt-4 ${
              effectiveChrome === 'clean-bleed' ? '' : 'border-t'
            }`}
            style={{ borderColor: slideBorder }}
          >
            <motion.div
              layoutId={transition.type === 'morph' ? 'slide-footnote' : undefined}
              className="flex items-center gap-3"
            >
              <EditableText
                value={slide.elements.footnote || `${effectiveBrand} · CONFIDENTIAL`}
                isEditMode={isEditMode}
                isSelected={selectedId === 'footnote'}
                onSelect={() => onSelectElement?.('footnote')}
                onSave={(val) =>
                  onUpdateSlide?.((prev) => ({
                    ...prev,
                    elements: { ...prev.elements, footnote: val },
                  }))
                }
                className="text-sm lg:text-base font-mono font-bold tracking-wider uppercase"
                style={{ color: isSlideDark ? 'rgba(255, 255, 255, 0.65)' : 'rgba(0, 0, 0, 0.65)' }}
                as="span"
              />
            </motion.div>

            {/* MANDATORY BOTTOM-RIGHT PAGE NUMBER (halaman wajib di pojok kanan bawah) */}
            {effectiveChrome === 'badge-capsule' || effectiveChrome === 'creative-studio' ? (
              <div
                className="rounded-full px-4 py-1.5 text-sm lg:text-base font-mono font-black tracking-widest border tabular-nums shadow-sm"
                style={{
                  backgroundColor: theme.surface,
                  borderColor: slideBorder,
                  color: isSlideDark ? '#FFFFFF' : '#0F172A',
                }}
              >
                {String(index + 1).padStart(2, '0')} / {String(totalSlides).padStart(2, '0')}
              </div>
            ) : (
              <span
                className="text-base lg:text-lg font-mono font-black tracking-widest tabular-nums"
                style={{ color: isSlideDark ? 'rgba(255, 255, 255, 0.85)' : 'rgba(0, 0, 0, 0.85)' }}
              >
                {String(index + 1).padStart(2, '0')} / {String(totalSlides).padStart(2, '0')}
              </span>
            )}
          </div>
        </motion.div>
      </AnimatePresence>
    </div>
  );
};

// Render layout-specific content
function renderLayoutContent(
  slide: Slide,
  theme: ThemeConfig,
  isMorph: boolean,
  isEditMode: boolean = false,
  selectedId?: string | null,
  onSelectElement?: (id: string | null) => void,
  onUpdateSlide?: (updater: (prev: Slide) => Slide) => void,
  onOpenImageEditor?: (imageKey: string) => void
) {
  // Support rendering arbitrary, rich, standalone HTML slides (pure 1-slide = 1 HTML file standard)
  if (slide.rawHtml || slide.elements?.rawHtml) {
    const raw = slide.rawHtml || slide.elements?.rawHtml || '';
    if (raw.includes('<html') || raw.includes('<!DOCTYPE')) {
      return (
        <div className="w-full h-full flex flex-col justify-center">
          <iframe
            srcDoc={raw}
            title={`html-slide-${slide.id}`}
            className="w-full h-full border-0 overflow-hidden"
            sandbox="allow-scripts allow-same-origin"
          />
        </div>
      );
    }
    return (
      <div
        className="w-full h-full relative overflow-hidden"
        dangerouslySetInnerHTML={{ __html: raw }}
      />
    );
  }

  // Dedicated Autonomous AI GEN Renderer (Single Option - Controlled by AI Agent)
  if (slide.layout === 'ai-gen' || (typeof slide.layout === 'string' && slide.layout.startsWith('ai-'))) {
    if (slide.elements?.rawHtml || slide.rawHtml) {
      return (
        <div
          className="w-full h-full relative overflow-hidden"
          dangerouslySetInnerHTML={{ __html: slide.elements?.rawHtml || slide.rawHtml || '' }}
        />
      );
    }

    const variant = slide.elements?.aiVariant || slide.layout;
    if (variant === 'klyro-hero' || variant === 'ai-klyro-hero') {
      return renderAiKlyroHero({ slide, theme, isMorph, isEditMode, selectedId, onSelectElement, onUpdateSlide, onOpenImageEditor, EditableText });
    }
    if (variant === 'klyro-split-stats' || variant === 'ai-klyro-split-stats') {
      return renderAiKlyroSplitStats({ slide, theme, isMorph, isEditMode, selectedId, onSelectElement, onUpdateSlide, onOpenImageEditor, EditableText });
    }
    if (variant === 'klyro-ticket-principles' || variant === 'ai-klyro-ticket-principles') {
      return renderAiKlyroTicketPrinciples({ slide, theme, isMorph, isEditMode, selectedId, onSelectElement, onUpdateSlide, onOpenImageEditor, EditableText });
    }
    if (variant === 'chuckle-retro-hero' || variant === 'ai-chuckle-retro-hero') {
      return renderAiChuckleRetroHero({ slide, theme, isMorph, isEditMode, selectedId, onSelectElement, onUpdateSlide, onOpenImageEditor, EditableText });
    }
    if (variant === 'borcelle-donut-data' || variant === 'ai-borcelle-donut-data') {
      return renderAiBorcelleDonutData({ slide, theme, isMorph, isEditMode, selectedId, onSelectElement, onUpdateSlide, onOpenImageEditor, EditableText });
    }
    if (variant === 'borcelle-venn-diagram' || variant === 'ai-borcelle-venn-diagram') {
      return renderAiBorcelleVennDiagram({ slide, theme, isMorph, isEditMode, selectedId, onSelectElement, onUpdateSlide, onOpenImageEditor, EditableText });
    }
    if (variant === 'fintech-ribbon-wave' || variant === 'ai-fintech-ribbon-wave') {
      return renderAiFintechRibbonWave({ slide, theme, isMorph, isEditMode, selectedId, onSelectElement, onUpdateSlide, onOpenImageEditor, EditableText });
    }

    // Adaptive Auto-Detection from Slide Content
    if (slide.elements?.comparison) {
      return renderAiBorcelleVennDiagram({ slide, theme, isMorph, isEditMode, selectedId, onSelectElement, onUpdateSlide, onOpenImageEditor, EditableText });
    }
    if (slide.elements?.metrics && slide.elements.metrics.length > 2) {
      return renderAiKlyroSplitStats({ slide, theme, isMorph, isEditMode, selectedId, onSelectElement, onUpdateSlide, onOpenImageEditor, EditableText });
    }
    if (slide.elements?.pillars && slide.elements.pillars.length > 0) {
      return renderAiKlyroTicketPrinciples({ slide, theme, isMorph, isEditMode, selectedId, onSelectElement, onUpdateSlide, onOpenImageEditor, EditableText });
    }

    return renderAiKlyroHero({ slide, theme, isMorph, isEditMode, selectedId, onSelectElement, onUpdateSlide, onOpenImageEditor, EditableText });
  }

  const meta = resolveLayoutMeta(slide.layout);
  const archetype = meta.archetype;

  switch (archetype) {
    case 'html':
      return (
        <div className="w-full h-full flex flex-col justify-center">
          <div
            className="w-full h-full relative overflow-hidden"
            dangerouslySetInnerHTML={{ __html: slide.elements?.rawHtml || '<p>Empty HTML slide</p>' }}
          />
        </div>
      );
    case 'cover':
      return (
        <div className="flex flex-col justify-center max-w-5xl">
          <div
            className="mb-6 inline-flex w-fit items-center gap-3 border px-5 py-2 text-sm font-mono font-bold tracking-widest uppercase"
            style={{
              borderColor: theme.border,
              backgroundColor: theme.surface,
              color: theme.textSecondary,
            }}
          >
            <SvgIcon name="sparkles" size={15} color={theme.accent} />
            <span>{slide.elements.callout?.kicker || 'EXECUTIVE BRIEFING · STRATEGY'}</span>
          </div>

          <motion.div
            layoutId={isMorph ? 'slide-title' : undefined}
            className="text-7xl lg:text-8xl font-black tracking-tight leading-[1.05] mb-6"
            style={{ color: slide.elements.titleColor || theme.textPrimary }}
          >
            <EditableText
              value={slide.title}
              isEditMode={isEditMode}
              isSelected={selectedId === 'title'}
              onSelect={() => onSelectElement?.('title')}
              onSave={(val) => onUpdateSlide?.((prev) => ({ ...prev, title: val }))}
              style={{ color: slide.elements.titleColor || theme.textPrimary }}
              as="h1"
            />
          </motion.div>

          <div
            className="text-3xl font-medium leading-relaxed max-w-4xl mb-6"
            style={{ color: slide.elements.subtitleColor || theme.textSecondary }}
          >
            <EditableText
              value={slide.subtitle}
              isEditMode={isEditMode}
              isSelected={selectedId === 'subtitle'}
              onSelect={() => onSelectElement?.('subtitle')}
              onSave={(val) => onUpdateSlide?.((prev) => ({ ...prev, subtitle: val }))}
              style={{ color: slide.elements.subtitleColor || theme.textSecondary }}
              as="p"
            />
          </div>

          {/* Executive Presentation Metadata Footer */}
          <div
            className="mt-8 flex items-center gap-10 border-t pt-5"
            style={{ borderColor: theme.border }}
          >
            <div className="flex flex-col gap-1.5">
              <span
                className="text-xs font-mono uppercase tracking-widest font-semibold flex items-center gap-2"
                style={{ color: theme.textMuted }}
              >
                <SvgIcon name="target" size={14} color={theme.textMuted} />
                INITIATIVE
              </span>
              <span className="text-lg font-bold" style={{ color: theme.textPrimary }}>
                {slide.elements.callout?.title || 'STRATEGIC DIRECTIVE'}
              </span>
            </div>
            <div className="h-10 w-[1px]" style={{ backgroundColor: theme.border }} />
            <div className="flex flex-col gap-1.5">
              <span
                className="text-xs font-mono uppercase tracking-widest font-semibold flex items-center gap-2"
                style={{ color: theme.textMuted }}
              >
                <SvgIcon name="shield" size={14} color={theme.textMuted} />
                SECURITY &amp; ACCESS
              </span>
              <span className="text-lg font-bold" style={{ color: theme.textPrimary }}>
                {slide.elements.footnote || 'CONFIDENTIAL · RESTRICTED'}
              </span>
            </div>
          </div>
        </div>
      );

    case 'team': {
      const teamMembers =
        slide.elements.team && slide.elements.team.length > 0
          ? slide.elements.team
          : DEFAULT_TEAM_MEMBERS.slice(0, 3);
      const is4Cols = teamMembers.length >= 4;
      return (
        <div className="flex flex-col justify-center w-full">
          <div className="mb-4 max-w-4xl flex flex-col gap-1.5">
            <motion.div
              className="text-5xl lg:text-6xl font-black tracking-tight leading-tight"
              style={{ color: slide.elements.titleColor || theme.textPrimary }}
            >
              <EditableText
                value={slide.title}
                isEditMode={isEditMode}
                isSelected={selectedId === 'title'}
                onSelect={() => onSelectElement?.('title')}
                onSave={(val) => onUpdateSlide?.((prev) => ({ ...prev, title: val }))}
                style={{ color: slide.elements.titleColor || theme.textPrimary }}
                as="h2"
              />
            </motion.div>
            <div
              className="text-xl leading-relaxed font-normal"
              style={{ color: slide.elements.subtitleColor || theme.textSecondary }}
            >
              <EditableText
                value={slide.subtitle}
                isEditMode={isEditMode}
                isSelected={selectedId === 'subtitle'}
                onSelect={() => onSelectElement?.('subtitle')}
                onSave={(val) => onUpdateSlide?.((prev) => ({ ...prev, subtitle: val }))}
                style={{ color: slide.elements.subtitleColor || theme.textSecondary }}
                as="p"
              />
            </div>
          </div>
          <div className={`grid ${is4Cols ? 'grid-cols-4 gap-6' : 'grid-cols-3 gap-8'}`}>
            {teamMembers.map((member, i) => {
              const cardId = `team-${i}`;
              const isCardSelected = selectedId === cardId;
              const pillColor = member.color || theme.accent;
              return (
                <motion.div
                  key={member.id || i}
                  onClick={(e) => {
                    if (isEditMode) {
                      e.stopPropagation();
                      onSelectElement?.(cardId);
                    }
                  }}
                  className={`relative border p-5 flex flex-col transition-all ${
                    isCardSelected
                      ? 'ring-2 ring-emerald-400 bg-emerald-500/10 shadow-lg'
                      : isEditMode
                      ? 'hover:border-zinc-500 cursor-pointer'
                      : ''
                  }`}
                  style={{
                    backgroundColor: theme.surface,
                    borderColor: isCardSelected ? '#10B981' : pillColor ? pillColor + '55' : theme.border,
                  }}
                >
                  {/* Portrait Image Container */}
                  <div
                    className="w-full h-[260px] overflow-hidden mb-3.5 relative border"
                    style={{ borderColor: theme.border }}
                  >
                    <img
                      src={member.avatarUrl || DEFAULT_TEAM_MEMBERS[i % 4].avatarUrl}
                      alt={member.name}
                      className="w-full h-full object-cover object-top"
                    />
                  </div>
                  {/* Role Pill Badge */}
                  <div className="mb-2">
                    <span
                      className="inline-block px-3 py-1 text-xs font-mono font-bold tracking-wider uppercase rounded-sm"
                      style={{
                        backgroundColor: pillColor,
                        color: '#000000',
                      }}
                    >
                      {member.role}
                    </span>
                  </div>
                  {/* Name */}
                  <div
                    className="text-2xl font-bold tracking-tight mb-1"
                    style={{ color: theme.textPrimary }}
                  >
                    <EditableText
                      value={member.name}
                      isEditMode={isEditMode}
                      isSelected={selectedId === `${cardId}-name`}
                      onSelect={() => onSelectElement?.(cardId)}
                      onSave={(val) =>
                        onUpdateSlide?.((prev) => {
                          const currentTeam = prev.elements.team
                            ? [...prev.elements.team]
                            : [...DEFAULT_TEAM_MEMBERS.slice(0, 3)];
                          currentTeam[i] = { ...currentTeam[i], name: val };
                          return { ...prev, elements: { ...prev.elements, team: currentTeam } };
                        })
                      }
                      as="h3"
                    />
                  </div>
                  {/* Bio */}
                  <div className="text-sm leading-relaxed" style={{ color: theme.textSecondary }}>
                    <EditableText
                      value={member.bio || ''}
                      isEditMode={isEditMode}
                      isSelected={selectedId === `${cardId}-bio`}
                      onSelect={() => onSelectElement?.(cardId)}
                      onSave={(val) =>
                        onUpdateSlide?.((prev) => {
                          const currentTeam = prev.elements.team
                            ? [...prev.elements.team]
                            : [...DEFAULT_TEAM_MEMBERS.slice(0, 3)];
                          currentTeam[i] = { ...currentTeam[i], bio: val };
                          return { ...prev, elements: { ...prev.elements, team: currentTeam } };
                        })
                      }
                      as="p"
                    />
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      );
    }

    case 'process': {
      const steps =
        slide.elements.steps && slide.elements.steps.length > 0
          ? slide.elements.steps
          : DEFAULT_PROCESS_STEPS;
      const count = steps.length;
      return (
        <div className="flex flex-col justify-center">
          <div className="mb-6 max-w-4xl flex flex-col gap-2">
            <motion.div
              className="text-6xl font-black tracking-tight leading-tight"
              style={{ color: slide.elements.titleColor || theme.textPrimary }}
            >
              <EditableText
                value={slide.title}
                isEditMode={isEditMode}
                isSelected={selectedId === 'title'}
                onSelect={() => onSelectElement?.('title')}
                onSave={(val) => onUpdateSlide?.((prev) => ({ ...prev, title: val }))}
                style={{ color: slide.elements.titleColor || theme.textPrimary }}
                as="h2"
              />
            </motion.div>
            <div
              className="text-2xl leading-relaxed font-normal"
              style={{ color: slide.elements.subtitleColor || theme.textSecondary }}
            >
              <EditableText
                value={slide.subtitle}
                isEditMode={isEditMode}
                isSelected={selectedId === 'subtitle'}
                onSelect={() => onSelectElement?.('subtitle')}
                onSave={(val) => onUpdateSlide?.((prev) => ({ ...prev, subtitle: val }))}
                style={{ color: slide.elements.subtitleColor || theme.textSecondary }}
                as="p"
              />
            </div>
          </div>
          <div className={`grid ${count >= 5 ? 'grid-cols-5' : 'grid-cols-4'} gap-5`}>
            {steps.map((st, i) => {
              const cardId = `step-${i}`;
              const isCardSelected = selectedId === cardId;
              const stepColor = st.color || theme.accent;
              return (
                <motion.div
                  key={st.id || i}
                  onClick={(e) => {
                    if (isEditMode) {
                      e.stopPropagation();
                      onSelectElement?.(cardId);
                    }
                  }}
                  className={`relative border p-6 flex flex-col justify-between transition-all min-h-[350px] ${
                    isCardSelected
                      ? 'ring-2 ring-emerald-400 bg-emerald-500/10 shadow-lg'
                      : isEditMode
                      ? 'hover:border-zinc-500 cursor-pointer'
                      : ''
                  }`}
                  style={{
                    backgroundColor: theme.surface,
                    borderColor: isCardSelected ? '#10B981' : stepColor ? stepColor + '55' : theme.border,
                  }}
                >
                  {stepColor && (
                    <div
                      className="absolute top-0 left-0 right-0 h-1.5"
                      style={{ backgroundColor: stepColor }}
                    />
                  )}
                  <div>
                    {/* Step Number in giant font */}
                    <div
                      className="flex items-center justify-between mb-4 border-b pb-3"
                      style={{ borderColor: theme.border }}
                    >
                      <span className="text-4xl font-mono font-black" style={{ color: stepColor }}>
                        {st.stepNumber || `0${i + 1}`}
                      </span>
                      <span
                        className="text-xs font-mono font-bold uppercase tracking-widest"
                        style={{ color: theme.textMuted }}
                      >
                        PHASE {i + 1}
                      </span>
                    </div>
                    {/* Title */}
                    <div
                      className="text-xl font-bold tracking-tight mb-2.5"
                      style={{ color: theme.textPrimary }}
                    >
                      <EditableText
                        value={st.title}
                        isEditMode={isEditMode}
                        isSelected={selectedId === `${cardId}-title`}
                        onSelect={() => onSelectElement?.(cardId)}
                        onSave={(val) =>
                          onUpdateSlide?.((prev) => {
                            const currentSteps = prev.elements.steps
                              ? [...prev.elements.steps]
                              : [...DEFAULT_PROCESS_STEPS];
                            currentSteps[i] = { ...currentSteps[i], title: val };
                            return { ...prev, elements: { ...prev.elements, steps: currentSteps } };
                          })
                        }
                        as="h3"
                      />
                    </div>
                    {/* Description */}
                    <div
                      className="text-sm font-normal leading-relaxed"
                      style={{ color: theme.textSecondary }}
                    >
                      <EditableText
                        value={st.description}
                        isEditMode={isEditMode}
                        isSelected={selectedId === `${cardId}-desc`}
                        onSelect={() => onSelectElement?.(cardId)}
                        onSave={(val) =>
                          onUpdateSlide?.((prev) => {
                            const currentSteps = prev.elements.steps
                              ? [...prev.elements.steps]
                              : [...DEFAULT_PROCESS_STEPS];
                            currentSteps[i] = { ...currentSteps[i], description: val };
                            return { ...prev, elements: { ...prev.elements, steps: currentSteps } };
                          })
                        }
                        as="p"
                      />
                    </div>
                  </div>
                  {/* Step Footer Indicator */}
                  <div
                    className="mt-4 pt-3 border-t flex items-center gap-2"
                    style={{ borderColor: theme.border }}
                  >
                    <span className="h-2 w-2 rounded-full" style={{ backgroundColor: stepColor }} />
                    <span
                      className="text-[10px] font-mono uppercase tracking-wider font-semibold"
                      style={{ color: theme.textMuted }}
                    >
                      STAGE VERIFIED
                    </span>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      );
    }

    case 'metrics':
      return (
        <div className="flex flex-col justify-center">
          <div className="mb-6 max-w-4xl flex flex-col gap-2">
            <motion.div
              className="text-6xl font-black tracking-tight leading-tight"
              style={{ color: slide.elements.titleColor || theme.textPrimary }}
            >
              <EditableText
                value={slide.title}
                isEditMode={isEditMode}
                isSelected={selectedId === 'title'}
                onSelect={() => onSelectElement?.('title')}
                onSave={(val) => onUpdateSlide?.((prev) => ({ ...prev, title: val }))}
                style={{ color: slide.elements.titleColor || theme.textPrimary }}
                as="h2"
              />
            </motion.div>
            <div className="text-2xl leading-relaxed font-normal" style={{ color: slide.elements.subtitleColor || theme.textSecondary }}>
              <EditableText
                value={slide.subtitle}
                isEditMode={isEditMode}
                isSelected={selectedId === 'subtitle'}
                onSelect={() => onSelectElement?.('subtitle')}
                onSave={(val) => onUpdateSlide?.((prev) => ({ ...prev, subtitle: val }))}
                style={{ color: slide.elements.subtitleColor || theme.textSecondary }}
                as="p"
              />
            </div>
          </div>
          <div className="grid grid-cols-4 gap-6">
            {slide.elements.metrics?.map((metric, i) => {
              const cardId = `metric-${i}`;
              const isCardSelected = selectedId === cardId;
              const accentColor = metric.color || theme.accent;
              return (
                <motion.div
                  key={metric.id || i}
                  layoutId={isMorph ? `metric-card-${i}` : undefined}
                  onClick={(e) => {
                    if (isEditMode) {
                      e.stopPropagation();
                      onSelectElement?.(cardId);
                    }
                  }}
                  className={`relative flex flex-col justify-between border px-6 py-6 transition-all ${
                    isCardSelected
                      ? 'ring-2 ring-emerald-400 bg-emerald-500/10 shadow-lg'
                      : isEditMode
                      ? 'hover:border-zinc-500 cursor-pointer'
                      : ''
                  }`}
                  style={{
                    backgroundColor: theme.surface,
                    borderColor: isCardSelected ? '#10B981' : metric.color ? metric.color + '55' : theme.border,
                  }}
                >
                  {metric.color && (
                    <div className="absolute top-0 left-0 right-0 h-1.5" style={{ backgroundColor: metric.color }} />
                  )}
                  <TelemetryCrosshair color={metric.color || theme.textMuted} className="absolute top-2.5 right-2.5" />
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2.5">
                        <SvgIcon
                          name={metric.iconName || 'activity'}
                          size={18}
                          color={accentColor}
                        />
                        <EditableText
                          value={metric.label}
                          isEditMode={isEditMode}
                          isSelected={selectedId === `${cardId}-label`}
                          onSelect={() => onSelectElement?.(cardId)}
                          onSave={(val) =>
                            onUpdateSlide?.((prev) => {
                              const updated = [...(prev.elements.metrics || [])];
                              updated[i] = { ...updated[i], label: val };
                              return { ...prev, elements: { ...prev.elements, metrics: updated } };
                            })
                          }
                          className="text-base font-mono font-bold tracking-wider uppercase"
                          style={{ color: theme.textMuted }}
                          as="span"
                        />
                      </div>
                      {metric.change && (
                        <EditableText
                          value={metric.change}
                          isEditMode={isEditMode}
                          isSelected={selectedId === `${cardId}-change`}
                          onSelect={() => onSelectElement?.(cardId)}
                          onSave={(val) =>
                            onUpdateSlide?.((prev) => {
                              const updated = [...(prev.elements.metrics || [])];
                              updated[i] = { ...updated[i], change: val };
                              return { ...prev, elements: { ...prev.elements, metrics: updated } };
                            })
                          }
                          className="text-sm font-mono font-semibold border px-2.5 py-1"
                          style={{
                            borderColor: metric.color ? metric.color + '66' : theme.border,
                            backgroundColor: theme.surfaceRaised,
                            color: metric.color || theme.textPrimary,
                          }}
                          as="span"
                        />
                      )}
                    </div>
                    <div
                      className="text-6xl lg:text-7xl font-black tracking-tight mb-3 tabular-nums"
                      style={{ color: metric.color || theme.textPrimary }}
                    >
                      <EditableText
                        value={metric.value}
                        isEditMode={isEditMode}
                        isSelected={selectedId === `${cardId}-val`}
                        onSelect={() => onSelectElement?.(cardId)}
                        onSave={(val) =>
                          onUpdateSlide?.((prev) => {
                            const updated = [...(prev.elements.metrics || [])];
                            updated[i] = { ...updated[i], value: val };
                            return { ...prev, elements: { ...prev.elements, metrics: updated } };
                          })
                        }
                        style={{ color: metric.color || theme.textPrimary }}
                        as="div"
                      />
                    </div>
                  </div>
                  {metric.subtext && (
                    <div className="text-base font-medium leading-relaxed" style={{ color: theme.textSecondary }}>
                      <EditableText
                        value={metric.subtext}
                        isEditMode={isEditMode}
                        isSelected={selectedId === `${cardId}-sub`}
                        onSelect={() => onSelectElement?.(cardId)}
                        onSave={(val) =>
                          onUpdateSlide?.((prev) => {
                            const updated = [...(prev.elements.metrics || [])];
                            updated[i] = { ...updated[i], subtext: val };
                            return { ...prev, elements: { ...prev.elements, metrics: updated } };
                          })
                        }
                        as="p"
                      />
                    </div>
                  )}
                </motion.div>
              );
            })}
          </div>
        </div>
      );

    case 'split':
      return (
        <div className="flex flex-col justify-center">
          <div className="grid grid-cols-12 gap-14 items-start">
            {/* Left Column (5 Cols) */}
            <div className="col-span-5 min-w-0 flex flex-col justify-center">
              <motion.div
                className="text-6xl font-black tracking-tight mb-6 leading-tight"
                style={{ color: slide.elements.titleColor || theme.textPrimary }}
              >
                <EditableText
                  value={slide.title}
                  isEditMode={isEditMode}
                  isSelected={selectedId === 'title'}
                  onSelect={() => onSelectElement?.('title')}
                  onSave={(val) => onUpdateSlide?.((prev) => ({ ...prev, title: val }))}
                  style={{ color: slide.elements.titleColor || theme.textPrimary }}
                  as="h2"
                />
              </motion.div>
              <div
                className="text-2xl font-normal leading-relaxed mb-6"
                style={{ color: slide.elements.subtitleColor || theme.textSecondary }}
              >
                <EditableText
                  value={slide.subtitle}
                  isEditMode={isEditMode}
                  isSelected={selectedId === 'subtitle'}
                  onSelect={() => onSelectElement?.('subtitle')}
                  onSave={(val) => onUpdateSlide?.((prev) => ({ ...prev, subtitle: val }))}
                  style={{ color: slide.elements.subtitleColor || theme.textSecondary }}
                  as="p"
                />
              </div>

              {/* Dynamic Callout Box */}
              {(() => {
                const callout = slide.elements.callout || {
                  kicker: 'CORE ARCHITECTURE',
                  text: 'Structured mathematical boundaries preserve typographic rhythm and visual equilibrium without responsive slippage.',
                  iconName: 'cpu',
                  color: theme.accent,
                };
                const isCalloutSelected = selectedId === 'callout';
                const calloutColor = callout.color || theme.accent;
                return (
                  <div
                    onClick={(e) => {
                      if (isEditMode) {
                        e.stopPropagation();
                        onSelectElement?.('callout');
                      }
                    }}
                    className={`relative border px-6 py-5 transition-all ${
                      isCalloutSelected ? 'ring-2 ring-emerald-400 bg-emerald-500/10 shadow-lg' : isEditMode ? 'hover:border-zinc-500 cursor-pointer' : ''
                    }`}
                    style={{
                      backgroundColor: theme.surface,
                      borderColor: isCalloutSelected ? '#10B981' : callout.color ? callout.color + '66' : theme.border,
                    }}
                  >
                    {callout.color && (
                      <div className="absolute top-0 left-0 right-0 h-1.5" style={{ backgroundColor: callout.color }} />
                    )}
                    <TelemetryCrosshair color={callout.color || theme.textMuted} className="absolute top-2.5 right-2.5" />
                    <div className="flex items-center gap-2.5 mb-2.5">
                      <SvgIcon name={callout.iconName || 'cpu'} size={16} color={calloutColor} />
                      <EditableText
                        value={callout.kicker || 'CORE THESIS'}
                        isEditMode={isEditMode}
                        isSelected={selectedId === 'callout-kicker'}
                        onSelect={() => onSelectElement?.('callout')}
                        onSave={(val) =>
                          onUpdateSlide?.((prev) => ({
                            ...prev,
                            elements: {
                              ...prev.elements,
                              callout: { ...(prev.elements.callout || callout), kicker: val },
                            },
                          }))
                        }
                        className="text-sm font-mono uppercase tracking-widest font-bold"
                        style={{ color: calloutColor }}
                        as="span"
                      />
                    </div>
                    <div className="text-base font-medium leading-relaxed" style={{ color: theme.textPrimary }}>
                      <EditableText
                        value={callout.text}
                        isEditMode={isEditMode}
                        isSelected={selectedId === 'callout-text'}
                        onSelect={() => onSelectElement?.('callout')}
                        onSave={(val) =>
                          onUpdateSlide?.((prev) => ({
                            ...prev,
                            elements: {
                              ...prev.elements,
                              callout: { ...(prev.elements.callout || callout), text: val },
                            },
                          }))
                        }
                        as="p"
                      />
                    </div>
                  </div>
                );
              })()}
            </div>

            {/* Right Column (7 Cols) */}
            <div className="col-span-7 min-w-0 flex flex-col justify-center">
              {slide.elements.image ? (
                <SlideImageFrame
                  image={slide.elements.image}
                  theme={theme}
                  isEditMode={isEditMode}
                  isSelected={selectedId === 'slide-image'}
                  onSelect={() => onSelectElement?.('slide-image')}
                  onOpenEditor={() => onOpenImageEditor?.('slide-image')}
                  onUpdateCaption={(cap) =>
                    onUpdateSlide?.((prev) => ({
                      ...prev,
                      elements: {
                        ...prev.elements,
                        image: { ...(prev.elements.image || DEFAULT_SLIDE_IMAGE), caption: cap },
                      },
                    }))
                  }
                />
              ) : (
                <div className="flex flex-col gap-3.5">
                  {slide.elements.bullets?.map((bullet, i) => {
                    const bulletIcons = ['network', 'layers', 'terminal', 'shield', 'zap'];
                    const iconName = bulletIcons[i % bulletIcons.length];
                    const bulletId = `bullet-${i}`;
                    const isBulletSelected = selectedId === bulletId;
                    return (
                      <div
                        key={i}
                        onClick={(e) => {
                          if (isEditMode) {
                            e.stopPropagation();
                            onSelectElement?.(bulletId);
                          }
                        }}
                        className={`relative flex items-start gap-4 border px-6 py-5 transition-all ${
                          isBulletSelected ? 'ring-2 ring-emerald-400 bg-emerald-500/10 shadow-md' : isEditMode ? 'hover:border-zinc-500 cursor-pointer' : ''
                        }`}
                        style={{
                          backgroundColor: theme.surfaceRaised,
                          borderColor: isBulletSelected ? '#10B981' : theme.border,
                        }}
                      >
                        <div
                          className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center border"
                          style={{ borderColor: theme.border, backgroundColor: theme.surface }}
                        >
                          <SvgIcon name={iconName} size={16} color={theme.accent} />
                        </div>
                        <div
                          className="text-lg font-medium leading-relaxed flex-1"
                          style={{ color: theme.textPrimary }}
                        >
                          <EditableText
                            value={bullet}
                            isEditMode={isEditMode}
                            isSelected={selectedId === bulletId}
                            onSelect={() => onSelectElement?.(bulletId)}
                            onSave={(val) =>
                              onUpdateSlide?.((prev) => {
                                const updated = [...(prev.elements.bullets || [])];
                                updated[i] = val;
                                return { ...prev, elements: { ...prev.elements, bullets: updated } };
                              })
                            }
                            as="p"
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </div>
      );

    case 'image': {
      const slideImg = slide.elements.image || DEFAULT_SLIDE_IMAGE;
      const isImgSelected = selectedId === 'slide-image';
      return (
        <div className="flex flex-col justify-center">
          <div className="grid grid-cols-12 gap-14 items-center">
            {/* Left Narrative Column (5 Cols) */}
            <div className="col-span-5 min-w-0 flex flex-col justify-center">
              <motion.div
                className="text-5xl lg:text-6xl font-black tracking-tight mb-5 leading-tight"
                style={{ color: slide.elements.titleColor || theme.textPrimary }}
              >
                <EditableText
                  value={slide.title}
                  isEditMode={isEditMode}
                  isSelected={selectedId === 'title'}
                  onSelect={() => onSelectElement?.('title')}
                  onSave={(val) => onUpdateSlide?.((prev) => ({ ...prev, title: val }))}
                  style={{ color: slide.elements.titleColor || theme.textPrimary }}
                  as="h2"
                />
              </motion.div>
              <div
                className="text-xl font-normal leading-relaxed mb-6"
                style={{ color: slide.elements.subtitleColor || theme.textSecondary }}
              >
                <EditableText
                  value={slide.subtitle}
                  isEditMode={isEditMode}
                  isSelected={selectedId === 'subtitle'}
                  onSelect={() => onSelectElement?.('subtitle')}
                  onSave={(val) => onUpdateSlide?.((prev) => ({ ...prev, subtitle: val }))}
                  style={{ color: slide.elements.subtitleColor || theme.textSecondary }}
                  as="p"
                />
              </div>

              {/* Dynamic Callout Feature Box */}
              {(() => {
                const callout = slide.elements.callout || {
                  kicker: 'OPTICAL PRECISION',
                  text: 'Strict 16:9 geometry lock and zero-stretch focal calibration prevent visual distortion on any stage.',
                  iconName: 'target',
                  color: theme.accent,
                };
                const isCalloutSelected = selectedId === 'callout';
                const calloutColor = callout.color || theme.accent;
                return (
                  <div
                    onClick={(e) => {
                      if (isEditMode) {
                        e.stopPropagation();
                        onSelectElement?.('callout');
                      }
                    }}
                    className={`relative border px-6 py-5 transition-all ${
                      isCalloutSelected ? 'ring-2 ring-emerald-400 bg-emerald-500/10 shadow-lg' : isEditMode ? 'hover:border-zinc-500 cursor-pointer' : ''
                    }`}
                    style={{
                      backgroundColor: theme.surface,
                      borderColor: isCalloutSelected ? '#10B981' : callout.color ? callout.color + '66' : theme.border,
                    }}
                  >
                    {callout.color && (
                      <div className="absolute top-0 left-0 right-0 h-1.5" style={{ backgroundColor: callout.color }} />
                    )}
                    <TelemetryCrosshair color={callout.color || theme.textMuted} className="absolute top-2.5 right-2.5" />
                    <div className="flex items-center gap-2.5 mb-2.5">
                      <SvgIcon name={callout.iconName || 'target'} size={16} color={calloutColor} />
                      <EditableText
                        value={callout.kicker || 'FIELD TELEMETRY'}
                        isEditMode={isEditMode}
                        isSelected={selectedId === 'callout-kicker'}
                        onSelect={() => onSelectElement?.('callout')}
                        onSave={(val) =>
                          onUpdateSlide?.((prev) => ({
                            ...prev,
                            elements: {
                              ...prev.elements,
                              callout: { ...(prev.elements.callout || callout), kicker: val },
                            },
                          }))
                        }
                        className="text-sm font-mono uppercase tracking-widest font-bold"
                        style={{ color: calloutColor }}
                        as="span"
                      />
                    </div>
                    <div className="text-base font-medium leading-relaxed" style={{ color: theme.textPrimary }}>
                      <EditableText
                        value={callout.text}
                        isEditMode={isEditMode}
                        isSelected={selectedId === 'callout-text'}
                        onSelect={() => onSelectElement?.('callout')}
                        onSave={(val) =>
                          onUpdateSlide?.((prev) => ({
                            ...prev,
                            elements: {
                              ...prev.elements,
                              callout: { ...(prev.elements.callout || callout), text: val },
                            },
                          }))
                        }
                        as="p"
                      />
                    </div>
                  </div>
                );
              })()}
            </div>

            {/* Right Column: SlideImageFrame (7 Cols) */}
            <div className="col-span-7 min-w-0 flex flex-col justify-center">
              <SlideImageFrame
                image={slideImg}
                theme={theme}
                isEditMode={isEditMode}
                isSelected={isImgSelected}
                onSelect={() => onSelectElement?.('slide-image')}
                onOpenEditor={() => onOpenImageEditor?.('slide-image')}
                onUpdateCaption={(cap) =>
                  onUpdateSlide?.((prev) => ({
                    ...prev,
                    elements: {
                      ...prev.elements,
                      image: { ...(prev.elements.image || DEFAULT_SLIDE_IMAGE), caption: cap },
                    },
                  }))
                }
              />
            </div>
          </div>
        </div>
      );
    }

    case 'pillars':
    case 'timeline':
      return (
        <div className="flex flex-col justify-center">
          <div className="mb-6 max-w-4xl flex flex-col gap-2">
            <motion.div
              className="text-6xl font-black tracking-tight leading-tight"
              style={{ color: slide.elements.titleColor || theme.textPrimary }}
            >
              <EditableText
                value={slide.title}
                isEditMode={isEditMode}
                isSelected={selectedId === 'title'}
                onSelect={() => onSelectElement?.('title')}
                onSave={(val) => onUpdateSlide?.((prev) => ({ ...prev, title: val }))}
                style={{ color: slide.elements.titleColor || theme.textPrimary }}
                as="h2"
              />
            </motion.div>
            <div className="text-2xl leading-relaxed font-normal" style={{ color: slide.elements.subtitleColor || theme.textSecondary }}>
              <EditableText
                value={slide.subtitle}
                isEditMode={isEditMode}
                isSelected={selectedId === 'subtitle'}
                onSelect={() => onSelectElement?.('subtitle')}
                onSave={(val) => onUpdateSlide?.((prev) => ({ ...prev, subtitle: val }))}
                style={{ color: slide.elements.subtitleColor || theme.textSecondary }}
                as="p"
              />
            </div>
          </div>
          <div className="grid grid-cols-3 gap-6">
            {slide.elements.pillars?.map((pillar, i) => {
              const cardId = `pillar-${i}`;
              const isCardSelected = selectedId === cardId;
              const accentColor = pillar.color || theme.accent;
              return (
                <motion.div
                  key={pillar.id || i}
                  layoutId={isMorph ? `pillar-${i}` : undefined}
                  onClick={(e) => {
                    if (isEditMode) {
                      e.stopPropagation();
                      onSelectElement?.(cardId);
                    }
                  }}
                  className={`relative flex flex-col justify-between border px-6 py-6 transition-all ${
                    isCardSelected ? 'ring-2 ring-emerald-400 bg-emerald-500/10 shadow-lg' : isEditMode ? 'hover:border-zinc-500 cursor-pointer' : ''
                  }`}
                  style={{
                    backgroundColor: theme.surface,
                    borderColor: isCardSelected ? '#10B981' : pillar.color ? pillar.color + '55' : theme.border,
                  }}
                >
                  {pillar.color && (
                    <div className="absolute top-0 left-0 right-0 h-1.5" style={{ backgroundColor: pillar.color }} />
                  )}
                  <TelemetryCrosshair color={pillar.color || theme.textMuted} className="absolute top-2.5 right-2.5" />
                  <div>
                    <div
                      className="flex items-center justify-between mb-4 border-b pb-3"
                      style={{ borderColor: theme.border }}
                    >
                      <div className="flex items-center gap-2.5">
                        <SvgIcon
                          name={pillar.iconName || 'layers'}
                          size={18}
                          color={accentColor}
                        />
                        <EditableText
                          value={pillar.tag || `PILLAR 0${i + 1}`}
                          isEditMode={isEditMode}
                          isSelected={selectedId === `${cardId}-tag`}
                          onSelect={() => onSelectElement?.(cardId)}
                          onSave={(val) =>
                            onUpdateSlide?.((prev) => {
                              const updated = [...(prev.elements.pillars || [])];
                              updated[i] = { ...updated[i], tag: val };
                              return { ...prev, elements: { ...prev.elements, pillars: updated } };
                            })
                          }
                          className="text-base font-mono uppercase tracking-widest font-bold"
                          style={{ color: pillar.color || theme.textMuted }}
                          as="span"
                        />
                      </div>
                      <span className="text-base font-mono font-bold" style={{ color: pillar.color || theme.textSecondary }}>
                        0{i + 1}
                      </span>
                    </div>
                    <div
                      className="text-2xl font-bold tracking-tight mb-2.5"
                      style={{ color: theme.textPrimary }}
                    >
                      <EditableText
                        value={pillar.title}
                        isEditMode={isEditMode}
                        isSelected={selectedId === `${cardId}-title`}
                        onSelect={() => onSelectElement?.(cardId)}
                        onSave={(val) =>
                          onUpdateSlide?.((prev) => {
                            const updated = [...(prev.elements.pillars || [])];
                            updated[i] = { ...updated[i], title: val };
                            return { ...prev, elements: { ...prev.elements, pillars: updated } };
                          })
                        }
                        as="h3"
                      />
                    </div>
                    <div
                      className="text-lg font-normal leading-relaxed"
                      style={{ color: theme.textSecondary }}
                    >
                      <EditableText
                        value={pillar.description}
                        isEditMode={isEditMode}
                        isSelected={selectedId === `${cardId}-desc`}
                        onSelect={() => onSelectElement?.(cardId)}
                        onSave={(val) =>
                          onUpdateSlide?.((prev) => {
                            const updated = [...(prev.elements.pillars || [])];
                            updated[i] = { ...updated[i], description: val };
                            return { ...prev, elements: { ...prev.elements, pillars: updated } };
                          })
                        }
                        as="p"
                      />
                    </div>
                  </div>
                  <div
                    className="mt-5 pt-3 border-t flex items-center justify-between"
                    style={{ borderColor: theme.border }}
                  >
                    <span
                      className="text-xs font-mono uppercase tracking-wider font-semibold"
                      style={{ color: theme.textMuted }}
                    >
                      SYSTEM STANDARD APPROVED
                    </span>
                    <SvgIcon name="check-circle" size={15} color={pillar.color || theme.textMuted} />
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      );

    case 'bento':
      return (
        <div className="flex flex-col justify-center">
          <div className="mb-5 max-w-4xl flex flex-col gap-1.5">
            <motion.div
              className="text-5xl lg:text-6xl font-black tracking-tight leading-tight"
              style={{ color: slide.elements.titleColor || theme.textPrimary }}
            >
              <EditableText
                value={slide.title}
                isEditMode={isEditMode}
                isSelected={selectedId === 'title'}
                onSelect={() => onSelectElement?.('title')}
                onSave={(val) => onUpdateSlide?.((prev) => ({ ...prev, title: val }))}
                style={{ color: slide.elements.titleColor || theme.textPrimary }}
                as="h2"
              />
            </motion.div>
            <div className="text-xl font-normal leading-relaxed" style={{ color: slide.elements.subtitleColor || theme.textSecondary }}>
              <EditableText
                value={slide.subtitle}
                isEditMode={isEditMode}
                isSelected={selectedId === 'subtitle'}
                onSelect={() => onSelectElement?.('subtitle')}
                onSave={(val) => onUpdateSlide?.((prev) => ({ ...prev, subtitle: val }))}
                style={{ color: slide.elements.subtitleColor || theme.textSecondary }}
                as="p"
              />
            </div>
          </div>
          <div className="grid grid-cols-3 gap-5">
            {slide.elements.bentoCards?.map((card, i) => {
              const cardId = `bento-${i}`;
              const isCardSelected = selectedId === cardId;
              const isWide = card.spanCol === 2;
              const accentColor = card.color || theme.accent;
              return (
                <motion.div
                  key={card.id || i}
                  layoutId={isMorph ? `bento-${i}` : undefined}
                  onClick={(e) => {
                    if (isEditMode) {
                      e.stopPropagation();
                      onSelectElement?.(cardId);
                    }
                  }}
                  className={`relative flex flex-col justify-between border px-6 py-5 transition-all ${
                    isWide ? 'col-span-2' : 'col-span-1'
                  } ${
                    isCardSelected ? 'ring-2 ring-emerald-400 bg-emerald-500/10 shadow-lg' : isEditMode ? 'hover:border-zinc-500 cursor-pointer' : ''
                  }`}
                  style={{
                    backgroundColor: theme.surface,
                    borderColor: isCardSelected ? '#10B981' : card.color ? card.color + '55' : theme.border,
                  }}
                >
                  {card.color && (
                    <div className="absolute top-0 left-0 right-0 h-1.5" style={{ backgroundColor: card.color }} />
                  )}
                  <TelemetryCrosshair color={card.color || theme.textMuted} className="absolute top-2.5 right-2.5" />
                  <div>
                    <div className="flex items-center justify-between mb-2.5">
                      <div className="flex items-center gap-2">
                        <SvgIcon
                          name={card.iconName || 'box'}
                          size={16}
                          color={accentColor}
                        />
                        <EditableText
                          value={card.subtitle || 'MODULE'}
                          isEditMode={isEditMode}
                          isSelected={selectedId === `${cardId}-sub`}
                          onSelect={() => onSelectElement?.(cardId)}
                          onSave={(val) =>
                            onUpdateSlide?.((prev) => {
                              const updated = [...(prev.elements.bentoCards || [])];
                              updated[i] = { ...updated[i], subtitle: val };
                              return {
                                ...prev,
                                elements: { ...prev.elements, bentoCards: updated },
                              };
                            })
                          }
                          className="text-sm font-mono uppercase tracking-widest font-bold"
                          style={{ color: card.color || theme.textMuted }}
                          as="span"
                        />
                      </div>
                      {card.badge && (
                        <EditableText
                          value={card.badge}
                          isEditMode={isEditMode}
                          isSelected={selectedId === `${cardId}-badge`}
                          onSelect={() => onSelectElement?.(cardId)}
                          onSave={(val) =>
                            onUpdateSlide?.((prev) => {
                              const updated = [...(prev.elements.bentoCards || [])];
                              updated[i] = { ...updated[i], badge: val };
                              return {
                                ...prev,
                                elements: { ...prev.elements, bentoCards: updated },
                              };
                            })
                          }
                          className="border px-2.5 py-0.5 text-xs font-mono uppercase tracking-wider font-semibold"
                          style={{
                            borderColor: card.color ? card.color + '66' : theme.border,
                            backgroundColor: theme.surfaceRaised,
                            color: card.color || theme.textPrimary,
                          }}
                          as="span"
                        />
                      )}
                    </div>
                    {card.image && (
                      <div className="my-2.5">
                        <SlideImageFrame
                          image={card.image}
                          theme={theme}
                          isEditMode={isEditMode}
                          isSelected={selectedId === `${cardId}-img`}
                          onSelect={() => onSelectElement?.(`${cardId}-img`)}
                          onOpenEditor={() => onOpenImageEditor?.(`bento-${i}-img`)}
                          aspectRatioOverride="16/9"
                        />
                      </div>
                    )}
                    <div
                      className="text-2xl font-bold tracking-tight mb-2"
                      style={{ color: theme.textPrimary }}
                    >
                      <EditableText
                        value={card.title}
                        isEditMode={isEditMode}
                        isSelected={selectedId === `${cardId}-title`}
                        onSelect={() => onSelectElement?.(cardId)}
                        onSave={(val) =>
                          onUpdateSlide?.((prev) => {
                            const updated = [...(prev.elements.bentoCards || [])];
                            updated[i] = { ...updated[i], title: val };
                            return {
                              ...prev,
                              elements: { ...prev.elements, bentoCards: updated },
                            };
                          })
                        }
                        as="h3"
                      />
                    </div>
                    <div
                      className="text-base lg:text-lg font-normal leading-relaxed"
                      style={{ color: theme.textSecondary }}
                    >
                      <EditableText
                        value={card.description}
                        isEditMode={isEditMode}
                        isSelected={selectedId === `${cardId}-desc`}
                        onSelect={() => onSelectElement?.(cardId)}
                        onSave={(val) =>
                          onUpdateSlide?.((prev) => {
                            const updated = [...(prev.elements.bentoCards || [])];
                            updated[i] = { ...updated[i], description: val };
                            return {
                              ...prev,
                              elements: { ...prev.elements, bentoCards: updated },
                            };
                          })
                        }
                        as="p"
                      />
                    </div>
                  </div>
                  {card.stat && (
                    <div
                      className="mt-3.5 border-t pt-2.5 flex items-baseline justify-between"
                      style={{ borderColor: theme.border }}
                    >
                      <span
                        className="text-xs font-mono uppercase tracking-wider font-semibold"
                        style={{ color: theme.textMuted }}
                      >
                        TELEMETRY RATING
                      </span>
                      <EditableText
                        value={card.stat}
                        isEditMode={isEditMode}
                        isSelected={selectedId === `${cardId}-stat`}
                        onSelect={() => onSelectElement?.(cardId)}
                        onSave={(val) =>
                          onUpdateSlide?.((prev) => {
                            const updated = [...(prev.elements.bentoCards || [])];
                            updated[i] = { ...updated[i], stat: val };
                            return {
                              ...prev,
                              elements: { ...prev.elements, bentoCards: updated },
                            };
                          })
                        }
                        className="text-2xl font-bold font-mono"
                        style={{ color: card.color || theme.textPrimary }}
                        as="span"
                      />
                    </div>
                  )}
                </motion.div>
              );
            })}
          </div>
        </div>
      );

    case 'quote':
      return (
        <div className="flex flex-col justify-center max-w-5xl mx-auto text-center py-6">
          <div className="mb-8 flex justify-center">
            <span
              className="border px-5 py-2 text-sm font-mono tracking-widest uppercase font-bold flex items-center gap-2.5"
              style={{
                borderColor: theme.border,
                backgroundColor: theme.surface,
                color: theme.textMuted,
              }}
            >
              <SvgIcon name="sparkles" size={15} color={theme.accent} />
              EXECUTIVE DOCTRINE
            </span>
          </div>
          <blockquote className="relative my-8">
            <div
              className="text-5xl md:text-6xl font-serif font-normal leading-[1.3] tracking-tight mb-10"
              style={{ color: theme.textPrimary }}
            >
              &ldquo;
              <EditableText
                value={slide.elements.quote?.text || slide.subtitle}
                isEditMode={isEditMode}
                onSave={(val) =>
                  onUpdateSlide?.((prev) => ({
                    ...prev,
                    elements: {
                      ...prev.elements,
                      quote: {
                        ...(prev.elements.quote || { author: 'EXECUTIVE', role: 'LEAD' }),
                        text: val,
                      },
                    },
                  }))
                }
                as="span"
              />
              &rdquo;
            </div>
            <div className="flex flex-col items-center justify-center gap-2">
              <EditableText
                value={slide.elements.quote?.author || 'PRINCIPAL ARCHITECT'}
                isEditMode={isEditMode}
                onSave={(val) =>
                  onUpdateSlide?.((prev) => ({
                    ...prev,
                    elements: {
                      ...prev.elements,
                      quote: {
                        ...(prev.elements.quote || { text: prev.subtitle, role: 'LEAD' }),
                        author: val,
                      },
                    },
                  }))
                }
                className="text-2xl font-bold tracking-wider uppercase"
                style={{ color: theme.textPrimary }}
                as="span"
              />
              <EditableText
                value={slide.elements.quote?.role || 'SYSTEMS DESIGN & ENGINEERING'}
                isEditMode={isEditMode}
                onSave={(val) =>
                  onUpdateSlide?.((prev) => ({
                    ...prev,
                    elements: {
                      ...prev.elements,
                      quote: {
                        ...(prev.elements.quote || { text: prev.subtitle, author: 'EXECUTIVE' }),
                        role: val,
                      },
                    },
                  }))
                }
                className="text-base font-mono tracking-widest uppercase"
                style={{ color: theme.textMuted }}
                as="span"
              />
            </div>
          </blockquote>
        </div>
      );

    case 'comparison':
      const comp = slide.elements.comparison;
      return (
        <div className="flex flex-col justify-center">
          <div className="mb-6 max-w-4xl flex flex-col gap-2">
            <motion.div
              className="text-6xl font-black tracking-tight leading-tight"
              style={{ color: slide.elements.titleColor || theme.textPrimary }}
            >
              <EditableText
                value={slide.title}
                isEditMode={isEditMode}
                onSave={(val) => onUpdateSlide?.((prev) => ({ ...prev, title: val }))}
                as="h2"
              />
            </motion.div>
            <div className="text-2xl leading-relaxed font-normal" style={{ color: theme.textSecondary }}>
              <EditableText
                value={slide.subtitle}
                isEditMode={isEditMode}
                onSave={(val) => onUpdateSlide?.((prev) => ({ ...prev, subtitle: val }))}
                as="p"
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-8">
            {/* Left Box */}
            <div
              className="relative border px-7 py-6 flex flex-col justify-between"
              style={{
                backgroundColor: theme.surface,
                borderColor: theme.border,
              }}
            >
              <TelemetryCrosshair color={theme.textMuted} className="absolute top-2.5 right-2.5" />
              <div>
                <EditableText
                  value={comp?.leftTitle || 'BASELINE SYSTEM'}
                  isEditMode={isEditMode}
                  onSave={(val) =>
                    onUpdateSlide?.((prev) => ({
                      ...prev,
                      elements: {
                        ...prev.elements,
                        comparison: {
                          ...(prev.elements.comparison || {
                            leftItems: [],
                            rightTitle: '',
                            rightItems: [],
                          }),
                          leftTitle: val,
                        },
                      },
                    }))
                  }
                  className="text-base font-mono uppercase tracking-widest block mb-4 border-b pb-3 font-bold"
                  style={{ color: theme.textMuted, borderColor: theme.border }}
                  as="h3"
                />
                <ul className="flex flex-col gap-3.5">
                  {comp?.leftItems?.map((item, i) => (
                    <li
                      key={i}
                      className="flex items-start gap-3.5 text-lg leading-relaxed font-normal"
                      style={{ color: theme.textSecondary }}
                    >
                      <span className="text-sm font-mono text-zinc-500 mt-1">✕</span>
                      <EditableText
                        value={item}
                        isEditMode={isEditMode}
                        onSave={(val) =>
                          onUpdateSlide?.((prev) => {
                            const updated = [...(prev.elements.comparison?.leftItems || [])];
                            updated[i] = val;
                            return {
                              ...prev,
                              elements: {
                                ...prev.elements,
                                comparison: {
                                  ...(prev.elements.comparison || {
                                    leftTitle: '',
                                    rightTitle: '',
                                    rightItems: [],
                                  }),
                                  leftItems: updated,
                                },
                              },
                            };
                          })
                        }
                        as="span"
                      />
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Right Box (Target Architecture) */}
            <div
              className="relative border px-7 py-6 flex flex-col justify-between"
              style={{
                backgroundColor: theme.surfaceRaised,
                borderColor: theme.accent,
              }}
            >
              <TelemetryCrosshair color={theme.accent} className="absolute top-2.5 right-2.5" />
              <div>
                <div
                  className="flex items-center justify-between mb-4 border-b pb-3"
                  style={{ borderColor: theme.border }}
                >
                  <EditableText
                    value={comp?.rightTitle || 'ARGON PLATFORM'}
                    isEditMode={isEditMode}
                    onSave={(val) =>
                      onUpdateSlide?.((prev) => ({
                        ...prev,
                        elements: {
                          ...prev.elements,
                          comparison: {
                            ...(prev.elements.comparison || {
                              leftTitle: '',
                              leftItems: [],
                              rightItems: [],
                            }),
                            rightTitle: val,
                          },
                        },
                      }))
                    }
                    className="text-base font-mono uppercase tracking-widest font-bold"
                    style={{ color: theme.textPrimary }}
                    as="h3"
                  />
                  <StatusPill label="SUPERIOR SOTA" color={theme.accent} />
                </div>
                <ul className="flex flex-col gap-3.5">
                  {comp?.rightItems?.map((item, i) => (
                    <li
                      key={i}
                      className="flex items-start gap-3.5 text-lg leading-relaxed font-medium"
                      style={{ color: theme.textPrimary }}
                    >
                      <SvgIcon name="check-circle" size={18} color={theme.accent} className="mt-1" />
                      <EditableText
                        value={item}
                        isEditMode={isEditMode}
                        onSave={(val) =>
                          onUpdateSlide?.((prev) => {
                            const updated = [...(prev.elements.comparison?.rightItems || [])];
                            updated[i] = val;
                            return {
                              ...prev,
                              elements: {
                                ...prev.elements,
                                comparison: {
                                  ...(prev.elements.comparison || {
                                    leftTitle: '',
                                    leftItems: [],
                                    rightTitle: '',
                                  }),
                                  rightItems: updated,
                                },
                              },
                            };
                          })
                        }
                        as="span"
                      />
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      );

    default:
      return null;
  }
}
